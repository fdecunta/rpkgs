# rpkgs

Prints to stdout unique packages used in R scripts.

## Description

A cli tool that scan R files and extract the packages used. 

It parses packages from these methods:

- `library(pkg)` / `require(pkg)`
- `pkg::func()`
- `pacman::p_load(pkg1, pkg2, ...)` (or multi-line calls)

Include options to print additional information:

- Filename where each package is used.
- Package version or empty if package is not installed.
- Package dependencies.
- Package recursive dependencies.
- Version for dependencies or recursive dependencies.

Dependencies work _only_ for packages available at CRAN.

The program consist of a small R package (_scanpkgs_) and a shell script (_rpkgs_).

## Usage

```
usage: rpkgs [-dHrv] file1 ...

Scan R files for packages used.

Options:
  -H  print with filename
  -d  dependencies
  -r  recursive dependencies (implies -d)
  -v  package version
```

## Install

```
make install
```

## Uninstall

```
make remove
```

## Examples

List packages found in file:

```
$ rpkgs test_files/00_test.R 
ENMeval
geodata
terra
predicts
usdm
```

Scan multiple files and add filenames, similar to `grep -H`:

```
rpkgs -H test_files/00_test.R test_files/01_test.R
test_files/00_test.R:ENMeval
test_files/00_test.R:geodata
test_files/00_test.R:terra
test_files/00_test.R:predicts
test_files/00_test.R:usdm
test_files/01_test.R:randomForest
test_files/01_test.R:terra
test_files/01_test.R:geodata
test_files/01_test.R:usdm
```

Show packages and their version:

```
$ rpkgs -v test_files/00_test.R
ENMeval:2.0.5.2
geodata:0.6.9
terra:1.9.34
predicts:0.2.2
usdm:2.1.7
```

The same, but
